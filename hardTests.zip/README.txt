./Bank 23 01.txt 02.txt 03.txt 04.txt 05.txt 06.txt 07.txt 08.txt 09.txt 10.txt 11.txt 12.txt 13.txt 14.txt 15.txt 16.txt 17.txt 18.txt 19.txt 20.txt 21.txt 22.txt 23.txt 

01 - open accounts success  (1)
02 - open accounts success  (2)
03 - open accounts same id
04 - deposit success
05 - deposit account not exists
06 - deposit wrong password
07 - withdrew success
08 - withdrew account not exists
09 - withdrew wrong password
10 - withdrew not enoght money
11 - get balance success (1)
12 - get balance success (2)
13 - get balance account not exists
14 - get balance wrong password
15 - transfer success (1)
16 - transfer success (2)
17 - transfer success (3)
18 - transfer account 1 not exists
19 - transfer account 2 not exists
20 - transfer both not exists
21 - transfer wrong password
22 - transfer not enoght money
23 - transfer same account
